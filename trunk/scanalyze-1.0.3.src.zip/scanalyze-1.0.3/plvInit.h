#ifdef __cplusplus
extern "C" {
#endif

#include <tcl.h>

int Plv_Init(Tcl_Interp *interp);

#ifdef __cplusplus
}
#endif


