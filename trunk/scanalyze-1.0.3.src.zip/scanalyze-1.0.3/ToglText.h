// ToglText.h             Wrapper for easy text output in a Togl widget
// created 4/30/99        magi@cs.stanford.edu


#ifndef _TOGLTEXT_H_
#define _TOGLTEXT_H_


void DrawText (struct Togl* togl, char* string);


#endif // _TOGLTEXT_H_
