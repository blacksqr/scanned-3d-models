/* ctafile.h.
 * interface to cta->rangegrid import routine
 */


RangeGrid *ImportCTAFile(char *filename, Pnt3 *avgView);
// Pnt3 *ImportCTAView(char *filename);
