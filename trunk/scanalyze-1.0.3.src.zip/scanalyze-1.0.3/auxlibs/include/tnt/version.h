// Template Numerical Toolkit (TNT) for Linear Algebra
//
// BETA VERSION INCOMPLETE AND SUBJECT TO CHANGE
// Please see http://math.nist.gov/tnt for updates
//
// R. Pozo
// Mathematical and Computational Sciences Division
// National Institute of Standards and Technology


#ifndef TNT_VERSION_H
#define TNT_VERSION_H

// Version 0.8.5

#define TNT_MAJOR_VERSION    0
#define TNT_MINOR_VERSION    8
#define TNT_SUBMINOR_VERSION 5

#endif
